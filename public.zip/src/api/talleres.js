const API_URL = 'https://mock.apidog.com/m1/879081-860552-default/talleres';

export const getTalleres = async () => {
  try {
    const res = await fetch(API_URL);
    if (!res.ok) throw new Error('Error al cargar talleres');
    return await res.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};
