import React from 'react';
import { Link } from 'react-router-dom';
import useAuth from '../hooks/useAuth';

const Navbar = () => {
  const { usuario, logout } = useAuth();

  return (
    <nav style={{ padding: '1rem', borderBottom: '1px solid #ccc' }}>
      <Link to="/" style={{ marginRight: '10px' }}>Inicio</Link>
      <Link to="/talleres" style={{ marginRight: '10px' }}>Talleres</Link>
      <Link to="/mis-reservas" style={{ marginRight: '10px' }}>Mis reservas</Link>
      {!usuario ? (
        <Link to="/login">Login</Link>
      ) : (
        <>
          <span style={{ marginLeft: '20px' }}>Hola, {usuario.nombre}</span>
          <button onClick={logout} style={{ marginLeft: '10px' }}>Logout</button>
        </>
      )}
    </nav>
  );
};

export default Navbar;
