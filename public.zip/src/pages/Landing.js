import React from 'react';

const Landing = () => {
  return (
    <div className="landing">
      <h2>Bienvenida a TallerNow</h2>
      <p>Gestiona tus talleres de forma rápida y sencilla.</p>
    </div>
  );
};

export default Landing;
