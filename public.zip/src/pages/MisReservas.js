import React, { useEffect, useState } from 'react';
import useAuth from '../hooks/useAuth';

const MisReservas = () => {
  const { usuario } = useAuth();
  const [reservas, setReservas] = useState([]);
  const [talleres, setTalleres] = useState([]);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    const cargarDatos = async () => {
      try {
        // 1. Traer reservas
        const resReservas = await fetch('https://mock.apidog.com/m1/879081-860552-default/reservas');
        const todas = await resReservas.json();
        const mias = todas.filter((r) => r.usuarioId === usuario.id);

        // 2. Traer talleres
        const resTalleres = await fetch('https://mock.apidog.com/m1/879081-860552-default/talleres');
        const talleresData = await resTalleres.json();

        setReservas(mias);
        setTalleres(talleresData);
      } catch (error) {
        console.error(error);
      } finally {
        setCargando(false);
      }
    };

    if (usuario) {
      cargarDatos();
    }
  }, [usuario]);

  if (cargando) return <p>Cargando tus reservas...</p>;
  if (reservas.length === 0) return <p>No tienes reservas.</p>;

  const obtenerTitulo = (id) => {
    const taller = talleres.find((t) => t.id === id);
    return taller ? taller.titulo : `Taller #${id}`;
  };

  return (
    <div className='mis-reservas'>
      <h2>Mis Reservas</h2>
      <ul className='lista-reservas'>
        {reservas.map((r) => (
          <li key={r.id}>
            {obtenerTitulo(r.tallerId)} – Reservado el {new Date(r.fecha_reserva).toLocaleDateString()}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MisReservas;
