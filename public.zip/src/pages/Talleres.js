import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getTalleres } from '../api/talleres';

const Talleres = () => {
  const [talleres, setTalleres] = useState([]);
  const [cargando, setCargando] = useState(true);

  useEffect(() => {
    const cargarTalleres = async () => {
        const datos = await getTalleres();
        console.log("Talleres cargados:", datos); // 👈 agrega esto
        setTalleres(datos);
        setCargando(false);
    };


    cargarTalleres();
  }, []);

  if (cargando) return <p>Cargando talleres...</p>;

  if (talleres.length === 0) return <p>No hay talleres disponibles.</p>;

  return (
    <div>
      <h2>Listado de Talleres</h2>
      <ul className='lista-talleres'>
        {talleres.map((taller) => (
          <li key={taller.id}>
            <Link to={`/talleres/${taller.id}`}>{taller.titulo}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Talleres;
