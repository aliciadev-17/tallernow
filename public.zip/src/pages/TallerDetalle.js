import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import useAuth from '../hooks/useAuth';

const TallerDetalle = () => {
  const { id } = useParams();
  const [taller, setTaller] = useState(null);
  const [cargando, setCargando] = useState(true);
  const { usuario } = useAuth(); 

  useEffect(() => {
    const cargarTaller = async () => {
      try {
        const res = await fetch(`https://mock.apidog.com/m1/879081-860552-default/talleres/${id}`);
        if (!res.ok) throw new Error('Error al cargar el taller');
        const data = await res.json();
        setTaller(data);
      } catch (error) {
        console.error(error);
      } finally {
        setCargando(false);
      }
    };

    cargarTaller();
  }, [id]);

  const reservarTaller = async () => {
    if (!usuario) {
      alert("Debes iniciar sesión para reservar.");
      return;
    }

    const reserva = {
      id_usuario: usuario.id,
      id_taller: taller.id,
      fecha_reserva: new Date().toISOString(),
    };

    try {
      const res = await fetch('https://mock.apidog.com/m1/879081-860552-default/reservas', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(reserva),
      });

      if (!res.ok) throw new Error('No se pudo completar la reserva');
      alert('¡Reserva realizada con éxito!');
    } catch (error) {
      console.error(error);
      alert('Error al reservar');
    }
  };

  if (cargando) return <p>Cargando taller...</p>;
  if (!taller) return <p>No se encontró el taller.</p>;

  return (
    <div className='detalle-taller'>
      <h2>{taller.titulo}</h2>
      <p><strong>Categoría:</strong> {taller.categoria}</p>
      <p><strong>Fecha:</strong> {taller.fecha}</p>
      <p><strong>Horario:</strong> {taller.horario}</p>
      <p><strong>Aforo:</strong> {taller.plazas_ocupadas} / {taller.aforo_maximo}</p>
      <p><strong>Descripción:</strong> {taller.descripcion}</p>
      {usuario && (
        <button onClick={reservarTaller}>Reservar este taller</button>
     )}

    </div>
  );
};

export default TallerDetalle;
