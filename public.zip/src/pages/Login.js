import React from 'react';
import { useNavigate } from 'react-router-dom';
import useAuth from '../hooks/useAuth';

const Login = () => {
  const { usuario, login } = useAuth();
  const navigate = useNavigate();

  const handleLogin = () => {
    const usuarioFicticio = {
      id: 1,
      nombre: 'Iratxe',
      email: 'iratxe@example.com',
    };

    login(usuarioFicticio);         // Guarda usuario en contexto
    navigate('/mis-reservas');      // Redirige a ruta protegida
  };

  if (usuario) {
    return <p>Ya has iniciado sesión como {usuario.nombre}.</p>;
  }

  return (
    <div>
      <h2>Iniciar sesión</h2>
      <button onClick={handleLogin}>Entrar como Iratxe</button>
    </div>
  );
};

export default Login;
