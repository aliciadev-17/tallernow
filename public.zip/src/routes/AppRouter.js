import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import Landing from '../pages/Landing';
import Login from '../pages/Login';
import Talleres from '../pages/Talleres';
import TallerDetalle from '../pages/TallerDetalle';
import MisReservas from '../pages/MisReservas';

import Navbar from '../components/Navbar';
import useAuth from '../hooks/useAuth';

const AppRouter = () => {
  const { usuario } = useAuth();

  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/talleres" element={<Talleres />} />
        <Route path="/talleres/:id" element={<TallerDetalle />} />
        <Route path="/talleres/:id" element={<TallerDetalle />} />
        <Route
          path="/mis-reservas"
          element={usuario ? <MisReservas /> : <Navigate to="/login" />}
        />
        <Route path="*" element={<h2>404 - Página no encontrada</h2>} />
      </Routes>
    </Router>
  );
};

export default AppRouter;
